/**
 * Created by Sasu on 20/03/2017.
 */
public enum Departamento {
    DEPNA, DEPSB, DEPSM, DEPSA
}
