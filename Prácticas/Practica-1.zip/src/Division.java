/**
 * Created by mrsas on 13/03/2017.
 */
public enum Division {
    DIVNA, DIVID, DIVHW, DIVSW, DIVSER
}
