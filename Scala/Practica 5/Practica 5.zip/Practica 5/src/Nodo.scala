/**
  * Created by mrsas on 01/06/2017.
  */
abstract class Nodo {

}
