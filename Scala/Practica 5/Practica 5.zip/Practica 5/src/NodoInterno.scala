/**
  * Created by mrsas on 01/06/2017.
  */
case class NodoInterno (val hijoIzquierda: Nodo, val hijoDerecha: Nodo, val caracteres: List[Char], val contador: Int) extends Nodo {
}
